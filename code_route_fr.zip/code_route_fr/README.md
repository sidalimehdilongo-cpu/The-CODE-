# Code de la route (France) — prototype Flutter

Prototype : banque de 200 questions courantes (dont 103 illustrées), entraînement gratuit de 20 questions tirées au hasard avec une publicité toutes les 3 questions, et un examen blanc verrouillé (déverrouillage de test local pour l'instant).

## Mise en route

1. Installer Flutter et Android Studio, puis :
   ```bash
   flutter create code_route_fr
   ```
2. Copier dans le projet créé : `pubspec.yaml`, `lib/main.dart`, `assets/questions_fr.json` (remplacer les fichiers générés).
3. Copier aussi le dossier `assets/images/` (66 illustrations SVG), déclaré dans `pubspec.yaml`.
4. Dans `android/app/src/main/AndroidManifest.xml`, ajouter dans la balise `<application>` :
   ```xml
   <meta-data
       android:name="com.google.android.gms.ads.APPLICATION_ID"
       android:value="ca-app-pub-3940256099942544~3347511713"/>
   ```
   (identifiant de test Google ; à remplacer par le vôtre).
5. Dans `android/app/build.gradle`, vérifier que `minSdkVersion` est au moins 23.
6. Lancer : `flutter pub get` puis `flutter run`.

## Avant publication

- **Publicités** : remplacer les identifiants de test (dans `main.dart` et le manifeste) par ceux de votre compte AdMob. Ne cliquez jamais sur vos propres publicités réelles.
- **Fréquence** : `adEveryNQuestions` dans `main.dart` règle la fréquence (3 actuellement). Une valeur plus élevée limite les désinstallations.
- **Achats** : brancher Google Play Billing (package `in_app_purchase`) dans `PurchaseService` à la place du déverrouillage de test.
- **Contenu** : les 200 questions sont originales mais doivent être relues et vérifiées avec les sources officielles (certaines règles évoluent). Les banques de questions officielles ne doivent pas être copiées.
- **Examen** : l'examen théorique général compte 40 questions et exige 35 bonnes réponses. L'examen blanc tire 40 questions au hasard parmi les 200.
- **Légal** : politique de confidentialité (obligatoire pour la publicité), consentement RGPD pour les publicités personnalisées (outil de consentement d'AdMob).
- **iOS** : la base de code est la même ; il faudra ajouter l'identifiant AdMob iOS et les achats via l'App Store.

## Ajouter des questions

Ajouter des objets dans `assets/questions_fr.json` avec les champs `id`, `theme`, `text`, `choices` (4 réponses), `correct` (indice de la bonne réponse), `explanation` et `image` (chemin d'un SVG dans `assets/images/`, ou `null`). L'ordre des réponses est mélangé automatiquement à l'affichage.

Les illustrations sont des SVG sans texte (le package `flutter_svg` ne gère pas la balise `<text>`).
