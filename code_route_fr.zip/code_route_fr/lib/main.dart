import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

/// Une publicité interstitielle toutes les N questions (mode entraînement).
const int adEveryNQuestions = 3;

/// Nombre de questions de l'entraînement gratuit.
const int practiceQuestionCount = 20;

/// Examen officiel (ETG) : 40 questions, 35 bonnes réponses minimum.
const int examQuestionCount = 40;
const double examPassRatio = 35 / 40;

/// IDENTIFIANT DE TEST Google (interstitiel Android). À remplacer avant publication.
const String interstitialAdUnitId = 'ca-app-pub-3940256099942544/1033173712';

// ---------------------------------------------------------------------------
// Modèle
// ---------------------------------------------------------------------------

class Question {
  Question({
    required this.id,
    required this.theme,
    required this.text,
    required this.choices,
    required this.correct,
    required this.explanation,
    this.image,
  });

  final String id;
  final String theme;
  final String text;
  final List<String> choices;
  final int correct;
  final String explanation;
  final String? image;

  /// Les réponses sont mélangées à chaque chargement : la bonne réponse
  /// n'est donc pas toujours à la même place.
  factory Question.fromJson(Map<String, dynamic> j) {
    final original = (j['choices'] as List).cast<String>();
    final order = List<int>.generate(original.length, (i) => i)..shuffle(Random());
    return Question(
      id: j['id'] as String,
      theme: j['theme'] as String,
      text: j['text'] as String,
      choices: order.map((i) => original[i]).toList(),
      correct: order.indexOf(j['correct'] as int),
      explanation: j['explanation'] as String,
      image: j['image'] as String?,
    );
  }
}

Future<List<Question>> loadQuestions() async {
  final raw = await rootBundle.loadString('assets/questions_fr.json');
  final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
  return list.map(Question.fromJson).toList();
}

// ---------------------------------------------------------------------------
// Services : publicité et achat
// ---------------------------------------------------------------------------

class AdService {
  AdService._();
  static final AdService instance = AdService._();

  InterstitialAd? _ad;

  void load() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _ad = ad,
        onAdFailedToLoad: (_) => _ad = null,
      ),
    );
  }

  /// Affiche la publicité si elle est prête, puis appelle [next].
  void showThen(VoidCallback next) {
    final ad = _ad;
    if (ad == null) {
      load();
      next();
      return;
    }
    _ad = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        load();
        next();
      },
      onAdFailedToShowFullScreenContent: (ad, _) {
        ad.dispose();
        load();
        next();
      },
    );
    ad.show();
  }
}

/// Gestion du déverrouillage des examens.
/// TODO : remplacer par Google Play Billing (package `in_app_purchase`).
/// Pour l'instant, le déverrouillage est local, uniquement pour tester l'interface.
class PurchaseService {
  static const _key = 'exam_unlocked';

  static Future<bool> isExamUnlocked() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_key) ?? false;
  }

  static Future<void> unlockForTesting() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_key, true);
  }
}

// ---------------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------------

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const CodeApp());
}

class CodeApp extends StatelessWidget {
  const CodeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Code de la route',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1E5AA8),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

// ---------------------------------------------------------------------------
// Accueil
// ---------------------------------------------------------------------------

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _examUnlocked = false;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final unlocked = await PurchaseService.isExamUnlocked();
    if (mounted) setState(() => _examUnlocked = unlocked);
  }

  Future<void> _startPractice() async {
    final all = await loadQuestions();
    all.shuffle(Random());
    final picked = all.take(practiceQuestionCount).toList();
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          questions: picked,
          isExam: false,
          showFeedback: true,
          showAds: true,
        ),
      ),
    );
  }

  Future<void> _startExam() async {
    if (!_examUnlocked) {
      await _showPaywall();
      return;
    }
    final all = await loadQuestions();
    all.shuffle(Random());
    final picked = all.take(examQuestionCount).toList();
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          questions: picked,
          isExam: true,
          showFeedback: false,
          showAds: false,
        ),
      ),
    );
  }

  Future<void> _showPaywall() async {
    final buy = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Examens blancs'),
        content: const Text(
          'Passez les examens blancs dans les conditions réelles, '
          'sans publicité, avec votre score final.\n\n'
          '(Version de test : le paiement Google Play sera branché ici.)',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Plus tard'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Débloquer'),
          ),
        ],
      ),
    );
    if (buy == true) {
      await PurchaseService.unlockForTesting();
      await _refresh();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Code de la route')),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.directions_car, size: 72),
            const SizedBox(height: 32),
            FilledButton.icon(
              onPressed: _startPractice,
              icon: const Icon(Icons.school),
              label: const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Entraînement gratuit (20 questions)'),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: _startExam,
              icon: Icon(_examUnlocked ? Icons.assignment : Icons.lock),
              label: const Padding(
                padding: EdgeInsets.all(12),
                child: Text('Examen blanc'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Quiz
// ---------------------------------------------------------------------------

class QuizScreen extends StatefulWidget {
  const QuizScreen({
    super.key,
    required this.questions,
    required this.isExam,
    required this.showFeedback,
    required this.showAds,
  });

  final List<Question> questions;
  final bool isExam;
  final bool showFeedback;
  final bool showAds;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _index = 0;
  int _score = 0;
  int? _selected;

  bool get _answered => _selected != null;

  @override
  void initState() {
    super.initState();
    if (widget.showAds) AdService.instance.load();
  }

  void _select(int i) {
    final q = widget.questions[_index];
    setState(() {
      _selected = i;
      if (i == q.correct) _score++;
    });
  }

  void _next() {
    final last = _index == widget.questions.length - 1;

    void go() {
      if (!mounted) return;
      if (last) {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultScreen(
              score: _score,
              total: widget.questions.length,
              isExam: widget.isExam,
            ),
          ),
        );
      } else {
        setState(() {
          _index++;
          _selected = null;
        });
      }
    }

    // La publicité s'affiche au clic sur « Suivant », jamais pendant une réponse.
    final showAd =
        widget.showAds && !last && (_index + 1) % adEveryNQuestions == 0;
    if (showAd) {
      AdService.instance.showThen(go);
    } else {
      go();
    }
  }

  Widget _choiceTile(Question q, int i) {
    Color? color;
    if (_answered && widget.showFeedback) {
      if (i == q.correct) {
        color = Colors.green.shade100;
      } else if (i == _selected) {
        color = Colors.red.shade100;
      }
    } else if (_answered && i == _selected) {
      color = Colors.blue.shade50;
    }
    return Card(
      color: color,
      child: ListTile(
        title: Text(q.choices[i]),
        onTap: _answered ? null : () => _select(i),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.questions[_index];
    final n = widget.questions.length;
    final last = _index == n - 1;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.isExam ? "Examen" : "Entraînement"} · ${_index + 1}/$n',
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LinearProgressIndicator(value: (_index + 1) / n),
          const SizedBox(height: 16),
          Text(q.theme, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          if (q.image != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: SvgPicture.asset(q.image!, height: 160),
            ),
          Text(q.text, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          for (int i = 0; i < q.choices.length; i++) _choiceTile(q, i),
          if (_answered && widget.showFeedback)
            Card(
              color: Colors.amber.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(q.explanation),
              ),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _answered ? _next : null,
            child: Text(last ? 'Terminer' : 'Suivant'),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Résultat
// ---------------------------------------------------------------------------

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.score,
    required this.total,
    required this.isExam,
  });

  final int score;
  final int total;
  final bool isExam;

  @override
  Widget build(BuildContext context) {
    final passMark = (total * examPassRatio).ceil();
    final passed = score >= passMark;

    return Scaffold(
      appBar: AppBar(title: const Text('Résultat')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$score / $total',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              const SizedBox(height: 16),
              if (isExam)
                Text(
                  passed
                      ? 'Réussi ! (minimum requis : $passMark)'
                      : 'Échoué. Minimum requis : $passMark',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              const SizedBox(height: 32),
              FilledButton(
                onPressed: () =>
                    Navigator.popUntil(context, (route) => route.isFirst),
                child: const Text('Retour à l\'accueil'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
