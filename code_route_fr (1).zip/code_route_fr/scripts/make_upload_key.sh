#!/usr/bin/env bash
# Crée votre clé d'envoi (une seule fois) et prépare sa version texte pour GitHub.
# CONSERVEZ upload-keystore.jks et ses mots de passe dans un endroit sûr (gestionnaire de mots de passe + copie).
# Ne les partagez avec personne, ne les envoyez pas dans un chat et ne les mettez pas dans le dépôt.
set -euo pipefail
keytool -genkeypair -v -keystore upload-keystore.jks -alias upload \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 upload-keystore.jks > upload-keystore.base64.txt 2>/dev/null || base64 upload-keystore.jks | tr -d '\n' > upload-keystore.base64.txt
echo "Créé : upload-keystore.jks et upload-keystore.base64.txt (contenu à coller dans le secret UPLOAD_KEYSTORE_BASE64)."
