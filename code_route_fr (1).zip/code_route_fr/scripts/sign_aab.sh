#!/usr/bin/env bash
# Signe un .aab avec votre clé d'envoi (upload key) pour la Play Console.
# Usage : KEYSTORE=upload-keystore.jks KEY_ALIAS=upload STORE_PASS=... KEY_PASS=... \
#         bash scripts/sign_aab.sh entree.aab sortie.aab
set -euo pipefail
IN="$1"; OUT="$2"
cp "$IN" "$OUT"
zip -q -d "$OUT" 'META-INF/*' || true
jarsigner -keystore "$KEYSTORE" -storepass "$STORE_PASS" -keypass "$KEY_PASS" \
  -sigalg SHA256withRSA -digestalg SHA-256 "$OUT" "$KEY_ALIAS"
jarsigner -verify "$OUT" | tail -1
