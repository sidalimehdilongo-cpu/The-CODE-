#!/usr/bin/env bash
# Génère le dossier android/ avec Flutter, puis applique les réglages nécessaires :
# identifiant unique, nom affiché, permission Internet, identifiant AdMob, minSdk 23.
# Variables : APP_ID (ex. com.monnom.coderoute), APP_LABEL, ADMOB_APP_ID.
set -euo pipefail

APP_ID="${APP_ID:-com.yourname.coderoute}"
APP_LABEL="${APP_LABEL:-Code de la route}"
ADMOB_APP_ID="${ADMOB_APP_ID:-}"
TEST_ADMOB_APP_ID="ca-app-pub-3940256099942544~3347511713"
[ -n "$ADMOB_APP_ID" ] || ADMOB_APP_ID="$TEST_ADMOB_APP_ID"

if [[ "$APP_ID" != *.*.* && "$APP_ID" != *.* ]]; then echo "APP_ID invalide : $APP_ID"; exit 1; fi
ORG="${APP_ID%.*}"
NAME="${APP_ID##*.}"
echo "Identifiant de l'application : $APP_ID"
[[ "$APP_ID" == com.yourname.* ]] && echo "ATTENTION : identifiant par défaut. Choisissez le vôtre avant de publier."
[[ "$ADMOB_APP_ID" == "$TEST_ADMOB_APP_ID" ]] && echo "ATTENTION : identifiant AdMob de test. Remplacez-le avant de publier."

TMP="$(mktemp -d)"
flutter create --org "$ORG" --project-name "$NAME" --platforms=android "$TMP/app" > /dev/null
rm -rf android
cp -r "$TMP/app/android" android

python3 - android/app/src/main/AndroidManifest.xml "$ADMOB_APP_ID" "$APP_LABEL" <<'PY'
import re, sys
path, admob, label = sys.argv[1:4]
s = open(path, encoding="utf-8").read()
s = re.sub(r'android:label="[^"]*"', f'android:label="{label}"', s, count=1)
if "android.permission.INTERNET" not in s:
    s = s.replace("<application", '<uses-permission android:name="android.permission.INTERNET"/>\n    <application', 1)
if "com.google.android.gms.ads.APPLICATION_ID" not in s:
    m = re.search(r"<application[^>]*>", s)
    meta = f'\n        <meta-data android:name="com.google.android.gms.ads.APPLICATION_ID" android:value="{admob}"/>'
    s = s[:m.end()] + meta + s[m.end():]
open(path, "w", encoding="utf-8").write(s)
PY

for f in android/app/build.gradle android/app/build.gradle.kts; do
  [ -f "$f" ] && sed -i -E 's/minSdk(Version)?[[:space:]]*=?[[:space:]]*flutter\.minSdkVersion/minSdk = 23/' "$f"
done
echo "Projet Android prêt."
