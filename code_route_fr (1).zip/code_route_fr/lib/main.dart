import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_svg/flutter_svg.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------

/// Une publicité interstitielle toutes les N questions (mode entraînement).
const int adEveryNQuestions = 3;

/// Nombre de questions de l'entraînement gratuit.
const int practiceQuestionCount = 20;

/// Identifiant de test Google (interstitiel). En production, passez le vôtre à la
/// compilation : --dart-define=ADMOB_INTERSTITIAL_ID=ca-app-pub-xxx/yyy
const String _testInterstitialId = 'ca-app-pub-3940256099942544/1033173712';
const String _adIdFromBuild = String.fromEnvironment('ADMOB_INTERSTITIAL_ID');
final String interstitialAdUnitId =
    _adIdFromBuild.isEmpty ? _testInterstitialId : _adIdFromBuild;

/// Achat simulé (APK de test uniquement) : --dart-define=FAKE_PURCHASE=true
const bool fakePurchase = bool.fromEnvironment('FAKE_PURCHASE');

/// Produit géré (non consommable) à créer dans la Play Console.
const String examProductId = 'exam_unlock';

// ---------------------------------------------------------------------------
// Textes de l'interface (une table par langue)
// ---------------------------------------------------------------------------

const Map<String, Map<String, String>> _tr = {
  'fr': {
    'app_title': 'Code de la route',
    'change_country': 'Changer de pays',
    'practice': 'Entraînement gratuit',
    'practice_sub': '{n} questions, avec corrections',
    'exam': 'Examen blanc',
    'q_count': '{n} questions',
    'pass_rule': '{p} bonnes réponses requises',
    'err_rule': '{e} erreurs maximum',
    'minutes': '{m} min',
    'free_ads': 'Version gratuite avec publicités',
    'paywall_title': 'Examens blancs',
    'paywall_body': 'Passez les examens blancs dans les conditions réelles de votre pays, sans publicité.',
    'store_error': 'Achat indisponible pour le moment.',
    'later': 'Plus tard',
    'unlock': 'Débloquer',
    'mode_practice': 'Entraînement',
    'mode_exam': 'Examen',
    'next': 'Suivant',
    'finish': 'Terminer',
    'result': 'Résultat',
    'passed': 'Réussi !',
    'failed': 'Échoué.',
    'need_pass': 'Minimum requis : {p}',
    'max_err': 'Erreurs autorisées : {e}',
    'time_up': 'Temps écoulé',
    'back_home': 'Retour à l\'accueil',
  },
  'en': {
    'app_title': 'Driving theory test',
    'change_country': 'Change country',
    'practice': 'Free practice',
    'practice_sub': '{n} questions, with explanations',
    'exam': 'Mock exam',
    'q_count': '{n} questions',
    'pass_rule': 'pass mark {p}',
    'err_rule': '{e} mistakes allowed',
    'minutes': '{m} min',
    'free_ads': 'Free version with ads',
    'paywall_title': 'Mock exams',
    'paywall_body': 'Take mock exams under the real conditions of your country, with no ads.',
    'store_error': 'Purchase unavailable right now.',
    'later': 'Later',
    'unlock': 'Unlock',
    'mode_practice': 'Practice',
    'mode_exam': 'Exam',
    'next': 'Next',
    'finish': 'Finish',
    'result': 'Result',
    'passed': 'Passed!',
    'failed': 'Failed.',
    'need_pass': 'Pass mark: {p}',
    'max_err': 'Mistakes allowed: {e}',
    'time_up': 'Time is up',
    'back_home': 'Back to home',
  },
  'es': {
    'app_title': 'Examen teórico de conducir',
    'change_country': 'Cambiar de país',
    'practice': 'Práctica gratuita',
    'practice_sub': '{n} preguntas, con explicaciones',
    'exam': 'Examen de prueba',
    'q_count': '{n} preguntas',
    'pass_rule': '{p} aciertos necesarios',
    'err_rule': 'máximo {e} fallos',
    'minutes': '{m} min',
    'free_ads': 'Versión gratuita con anuncios',
    'paywall_title': 'Exámenes de prueba',
    'paywall_body': 'Haz exámenes de prueba en las condiciones reales de tu país, sin anuncios.',
    'store_error': 'Compra no disponible en este momento.',
    'later': 'Más tarde',
    'unlock': 'Desbloquear',
    'mode_practice': 'Práctica',
    'mode_exam': 'Examen',
    'next': 'Siguiente',
    'finish': 'Terminar',
    'result': 'Resultado',
    'passed': '¡Aprobado!',
    'failed': 'Suspendido.',
    'need_pass': 'Mínimo necesario: {p}',
    'max_err': 'Fallos permitidos: {e}',
    'time_up': 'Tiempo agotado',
    'back_home': 'Volver al inicio',
  },
  'ja': {
    'app_title': '運転免許 学科試験',
    'change_country': '国を変更',
    'practice': '無料練習',
    'practice_sub': '{n}問・解説つき',
    'exam': '模擬試験',
    'q_count': '{n}問',
    'pass_rule': '{p}問以上正解で合格',
    'err_rule': '誤答{e}問まで',
    'minutes': '{m}分',
    'free_ads': '広告つき無料版',
    'paywall_title': '模擬試験',
    'paywall_body': 'お住まいの国の本番に近い条件で模擬試験を受けられます。広告は表示されません。',
    'store_error': '現在、購入できません。',
    'later': 'あとで',
    'unlock': 'ロック解除',
    'mode_practice': '練習',
    'mode_exam': '試験',
    'next': '次へ',
    'finish': '終了',
    'result': '結果',
    'passed': '合格!',
    'failed': '不合格',
    'need_pass': '合格ライン:{p}問',
    'max_err': '許容される誤答:{e}問',
    'time_up': '時間切れ',
    'back_home': 'ホームに戻る',
  },
  'it': {
    'app_title': 'Quiz patente',
    'change_country': 'Cambia paese',
    'practice': 'Allenamento gratuito',
    'practice_sub': '{n} domande, con spiegazioni',
    'exam': 'Esame di prova',
    'q_count': '{n} domande',
    'pass_rule': '{p} risposte corrette richieste',
    'err_rule': 'massimo {e} errori',
    'minutes': '{m} min',
    'free_ads': 'Versione gratuita con pubblicità',
    'paywall_title': 'Esami di prova',
    'paywall_body': 'Fai gli esami di prova nelle condizioni reali del tuo paese, senza pubblicità.',
    'store_error': 'Acquisto non disponibile al momento.',
    'later': 'Più tardi',
    'unlock': 'Sblocca',
    'mode_practice': 'Allenamento',
    'mode_exam': 'Esame',
    'next': 'Avanti',
    'finish': 'Termina',
    'result': 'Risultato',
    'passed': 'Promosso!',
    'failed': 'Bocciato.',
    'need_pass': 'Minimo richiesto: {p}',
    'max_err': 'Errori consentiti: {e}',
    'time_up': 'Tempo scaduto',
    'back_home': 'Torna alla home',
  },
};

String currentLang = 'fr';

String tr(String key, [Map<String, Object> params = const {}]) {
  var s = _tr[currentLang]?[key] ?? _tr['fr']![key] ?? key;
  params.forEach((k, v) => s = s.replaceAll('{$k}', '$v'));
  return s;
}

// ---------------------------------------------------------------------------
// Modèles
// ---------------------------------------------------------------------------

/// Règles de l'examen d'un pays : nombre de questions, seuil de réussite
/// (bonnes réponses requises OU erreurs maximum) et durée éventuelle.
class ExamRules {
  ExamRules({required this.questions, this.passMark, this.maxErrors, this.minutes});

  final int questions;
  final int? passMark;
  final int? maxErrors;
  final int? minutes;

  factory ExamRules.fromJson(Map<String, dynamic> j) => ExamRules(
        questions: j['questions'] as int,
        passMark: j['passMark'] as int?,
        maxErrors: j['maxErrors'] as int?,
        minutes: j['minutes'] as int?,
      );

  /// Si la banque est plus petite que l'examen officiel, le seuil est
  /// ramené proportionnellement.
  int requiredCorrect(int total) {
    if (passMark != null) return (total * passMark! / questions).ceil();
    final allowed = (maxErrors! * total / questions).floor();
    return total - allowed;
  }

  bool passed(int score, int total) => score >= requiredCorrect(total);
}

class Country {
  Country({
    required this.code,
    required this.name,
    required this.flag,
    required this.language,
    required this.file,
    required this.rules,
  });

  final String code;
  final String name;
  final String flag;
  final String language;
  final String file;
  final ExamRules rules;

  factory Country.fromJson(Map<String, dynamic> j) => Country(
        code: j['code'] as String,
        name: j['name'] as String,
        flag: j['flag'] as String,
        language: j['language'] as String,
        file: j['file'] as String,
        rules: ExamRules.fromJson(j['exam'] as Map<String, dynamic>),
      );
}

class Question {
  Question({
    required this.id,
    required this.theme,
    required this.text,
    required this.choices,
    required this.correct,
    required this.explanation,
    this.image,
  });

  final String id;
  final String theme;
  final String text;
  final List<String> choices;
  final int correct;
  final String explanation;
  final String? image;

  /// Les réponses sont mélangées à chaque chargement, sauf pour les questions
  /// vrai/faux (2 choix), dont l'ordre reste fixe.
  factory Question.fromJson(Map<String, dynamic> j) {
    final original = (j['choices'] as List).cast<String>();
    final order = List<int>.generate(original.length, (i) => i);
    if (original.length > 2) order.shuffle(Random());
    return Question(
      id: j['id'] as String,
      theme: j['theme'] as String,
      text: j['text'] as String,
      choices: order.map((i) => original[i]).toList(),
      correct: order.indexOf(j['correct'] as int),
      explanation: j['explanation'] as String,
      image: j['image'] as String?,
    );
  }
}

Future<List<Country>> loadCountries() async {
  final raw = await rootBundle.loadString('assets/countries.json');
  return (jsonDecode(raw) as List)
      .cast<Map<String, dynamic>>()
      .map(Country.fromJson)
      .toList();
}

Future<List<Question>> loadQuestions(Country c) async {
  final raw = await rootBundle.loadString(c.file);
  final list = (jsonDecode(raw) as List).cast<Map<String, dynamic>>();
  return list.map(Question.fromJson).toList();
}

// ---------------------------------------------------------------------------
// Services : publicité et achat
// ---------------------------------------------------------------------------

class AdService {
  AdService._();
  static final AdService instance = AdService._();

  InterstitialAd? _ad;

  void load() {
    InterstitialAd.load(
      adUnitId: interstitialAdUnitId,
      request: const AdRequest(),
      adLoadCallback: InterstitialAdLoadCallback(
        onAdLoaded: (ad) => _ad = ad,
        onAdFailedToLoad: (_) => _ad = null,
      ),
    );
  }

  /// Affiche la publicité si elle est prête, puis appelle [next].
  void showThen(VoidCallback next) {
    final ad = _ad;
    if (ad == null) {
      load();
      next();
      return;
    }
    _ad = null;
    ad.fullScreenContentCallback = FullScreenContentCallback(
      onAdDismissedFullScreenContent: (ad) {
        ad.dispose();
        load();
        next();
      },
      onAdFailedToShowFullScreenContent: (ad, _) {
        ad.dispose();
        load();
        next();
      },
    );
    ad.show();
  }
}

/// Déverrouillage des examens : un seul produit géré, valable pour tous les pays.
/// En mode FAKE_PURCHASE (APK de test), le déverrouillage est simulé.
class PurchaseService {
  static final InAppPurchase _iap = InAppPurchase.instance;
  static final ValueNotifier<bool> unlocked = ValueNotifier<bool>(false);
  static StreamSubscription<List<PurchaseDetails>>? _sub;

  static Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    unlocked.value = prefs.getBool('exam_unlocked') ?? false;
    if (fakePurchase) return;
    _sub = _iap.purchaseStream.listen(_onPurchases, onError: (_) {});
    try {
      await _iap.restorePurchases();
    } catch (_) {}
  }

  static Future<void> _onPurchases(List<PurchaseDetails> list) async {
    for (final p in list) {
      if (p.productID != examProductId) continue;
      if (p.status == PurchaseStatus.purchased || p.status == PurchaseStatus.restored) {
        await _setUnlocked(true);
      }
      if (p.pendingCompletePurchase) await _iap.completePurchase(p);
    }
  }

  static Future<void> _setUnlocked(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('exam_unlocked', v);
    unlocked.value = v;
  }

  /// Lance l'achat. Retourne un code d'erreur, ou null si l'achat est lancé.
  static Future<String?> buy() async {
    if (fakePurchase) {
      await _setUnlocked(true);
      return null;
    }
    if (!await _iap.isAvailable()) return 'store_unavailable';
    final r = await _iap.queryProductDetails({examProductId});
    if (r.productDetails.isEmpty) return 'product_missing';
    await _iap.buyNonConsumable(
      purchaseParam: PurchaseParam(productDetails: r.productDetails.first),
    );
    return null;
  }
}

// ---------------------------------------------------------------------------
// Application
// ---------------------------------------------------------------------------

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  await PurchaseService.init();
  runApp(const CodeApp());
}

class CodeApp extends StatelessWidget {
  const CodeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Driving theory',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1E5AA8),
        useMaterial3: true,
      ),
      home: const RootScreen(),
    );
  }
}

/// Charge la liste des pays et le pays mémorisé, puis affiche l'écran adapté.
class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  List<Country>? _countries;
  Country? _country;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final countries = await loadCountries();
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('country');
    Country? selected;
    for (final c in countries) {
      if (c.code == saved) selected = c;
    }
    if (selected != null) currentLang = selected.language;
    if (!mounted) return;
    setState(() {
      _countries = countries;
      _country = selected;
      _loading = false;
    });
  }

  Future<void> _select(Country c) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('country', c.code);
    currentLang = c.language;
    setState(() => _country = c);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    final c = _country;
    if (c == null) {
      return CountryScreen(countries: _countries!, onSelected: _select);
    }
    return HomeScreen(
      key: ValueKey(c.code),
      country: c,
      onChangeCountry: () => setState(() => _country = null),
    );
  }
}

// ---------------------------------------------------------------------------
// Choix du pays
// ---------------------------------------------------------------------------

class CountryScreen extends StatelessWidget {
  const CountryScreen({super.key, required this.countries, required this.onSelected});

  final List<Country> countries;
  final ValueChanged<Country> onSelected;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Choose your country · Choisissez votre pays')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final c in countries)
            Card(
              child: ListTile(
                leading: Text(c.flag, style: const TextStyle(fontSize: 32)),
                title: Text(c.name),
                subtitle: Text(c.language.toUpperCase()),
                onTap: () => onSelected(c),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Accueil
// ---------------------------------------------------------------------------

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.country, required this.onChangeCountry});

  final Country country;
  final VoidCallback onChangeCountry;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _examUnlocked = false;

  Country get _c => widget.country;

  @override
  void initState() {
    super.initState();
    _examUnlocked = PurchaseService.unlocked.value;
    PurchaseService.unlocked.addListener(_onUnlocked);
  }

  @override
  void dispose() {
    PurchaseService.unlocked.removeListener(_onUnlocked);
    super.dispose();
  }

  void _onUnlocked() {
    if (mounted) setState(() => _examUnlocked = PurchaseService.unlocked.value);
  }

  Future<void> _startPractice() async {
    final all = await loadQuestions(_c);
    all.shuffle(Random());
    final picked = all.take(practiceQuestionCount).toList();
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          questions: picked,
          isExam: false,
          showFeedback: true,
          showAds: true,
          rules: _c.rules,
        ),
      ),
    );
  }

  Future<void> _startExam() async {
    if (!_examUnlocked) {
      await _showPaywall();
      return;
    }
    final all = await loadQuestions(_c);
    all.shuffle(Random());
    final picked = all.take(min(_c.rules.questions, all.length)).toList();
    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => QuizScreen(
          questions: picked,
          isExam: true,
          showFeedback: false,
          showAds: false,
          rules: _c.rules,
        ),
      ),
    );
  }

  Future<void> _showPaywall() async {
    final buy = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr('paywall_title')),
        content: Text(tr('paywall_body')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text(tr('later')),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: Text(tr('unlock')),
          ),
        ],
      ),
    );
    if (buy == true) {
      final err = await PurchaseService.buy();
      if (err != null && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('store_error'))));
      }
    }
  }

  String _examSub() {
    final r = _c.rules;
    final parts = <String>[tr('q_count', {'n': r.questions})];
    if (r.passMark != null) parts.add(tr('pass_rule', {'p': r.passMark!}));
    if (r.maxErrors != null) parts.add(tr('err_rule', {'e': r.maxErrors!}));
    if (r.minutes != null) parts.add(tr('minutes', {'m': r.minutes!}));
    return parts.join(' · ');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('app_title')),
        actions: [
          TextButton(
            onPressed: widget.onChangeCountry,
            child: Text(_c.flag, style: const TextStyle(fontSize: 26)),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.directions_car, size: 72),
            const SizedBox(height: 32),
            FilledButton(
              onPressed: _startPractice,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    Text(tr('practice'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                    Text(tr('practice_sub', {'n': practiceQuestionCount})),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              onPressed: _startExam,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_examUnlocked ? Icons.assignment : Icons.lock),
                    const SizedBox(width: 12),
                    Flexible(
                      child: Column(
                        children: [
                          Text(tr('exam'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          Text(_examSub(), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(tr('free_ads'), textAlign: TextAlign.center),
            TextButton(
              onPressed: widget.onChangeCountry,
              child: Text(tr('change_country')),
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Quiz
// ---------------------------------------------------------------------------

class QuizScreen extends StatefulWidget {
  const QuizScreen({
    super.key,
    required this.questions,
    required this.isExam,
    required this.showFeedback,
    required this.showAds,
    required this.rules,
  });

  final List<Question> questions;
  final bool isExam;
  final bool showFeedback;
  final bool showAds;
  final ExamRules rules;

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  int _index = 0;
  int _score = 0;
  int? _selected;
  Timer? _timer;
  int _secondsLeft = 0;
  bool _finished = false;

  bool get _answered => _selected != null;

  @override
  void initState() {
    super.initState();
    if (widget.showAds) AdService.instance.load();
    final minutes = widget.rules.minutes;
    if (widget.isExam && minutes != null) {
      _secondsLeft = minutes * 60;
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (!mounted) return;
        setState(() => _secondsLeft--);
        if (_secondsLeft <= 0) {
          t.cancel();
          _finish(timeUp: true);
        }
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _select(int i) {
    final q = widget.questions[_index];
    setState(() {
      _selected = i;
      if (i == q.correct) _score++;
    });
  }

  void _finish({bool timeUp = false}) {
    if (_finished || !mounted) return;
    _finished = true;
    _timer?.cancel();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(
          score: _score,
          total: widget.questions.length,
          isExam: widget.isExam,
          rules: widget.rules,
          timeUp: timeUp,
        ),
      ),
    );
  }

  void _next() {
    final last = _index == widget.questions.length - 1;

    void go() {
      if (!mounted) return;
      if (last) {
        _finish();
      } else {
        setState(() {
          _index++;
          _selected = null;
        });
      }
    }

    // La publicité s'affiche au clic sur « Suivant », jamais pendant une réponse.
    final showAd = widget.showAds && !last && (_index + 1) % adEveryNQuestions == 0;
    if (showAd) {
      AdService.instance.showThen(go);
    } else {
      go();
    }
  }

  String _clock() {
    final m = (_secondsLeft ~/ 60).toString().padLeft(2, '0');
    final s = (_secondsLeft % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  Widget _choiceTile(Question q, int i) {
    Color? color;
    if (_answered && widget.showFeedback) {
      if (i == q.correct) {
        color = Colors.green.shade100;
      } else if (i == _selected) {
        color = Colors.red.shade100;
      }
    } else if (_answered && i == _selected) {
      color = Colors.blue.shade50;
    }
    return Card(
      color: color,
      child: ListTile(
        title: Text(q.choices[i]),
        onTap: _answered ? null : () => _select(i),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.questions[_index];
    final n = widget.questions.length;
    final last = _index == n - 1;
    final mode = widget.isExam ? tr('mode_exam') : tr('mode_practice');

    return Scaffold(
      appBar: AppBar(
        title: Text('$mode · ${_index + 1}/$n'),
        actions: [
          if (widget.isExam && widget.rules.minutes != null)
            Padding(
              padding: const EdgeInsets.only(right: 16),
              child: Center(
                child: Text(
                  _clock(),
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                    color: _secondsLeft < 60 ? Colors.red : null,
                  ),
                ),
              ),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          LinearProgressIndicator(value: (_index + 1) / n),
          const SizedBox(height: 16),
          Text(q.theme, style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          if (q.image != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: SvgPicture.asset(q.image!, height: 160),
            ),
          Text(q.text, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 16),
          for (int i = 0; i < q.choices.length; i++) _choiceTile(q, i),
          if (_answered && widget.showFeedback)
            Card(
              color: Colors.amber.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Text(q.explanation),
              ),
            ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: _answered ? _next : null,
            child: Text(last ? tr('finish') : tr('next')),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Résultat
// ---------------------------------------------------------------------------

class ResultScreen extends StatelessWidget {
  const ResultScreen({
    super.key,
    required this.score,
    required this.total,
    required this.isExam,
    required this.rules,
    this.timeUp = false,
  });

  final int score;
  final int total;
  final bool isExam;
  final ExamRules rules;
  final bool timeUp;

  @override
  Widget build(BuildContext context) {
    final need = rules.requiredCorrect(total);
    final passed = rules.passed(score, total);
    final errorsAllowed = total - need;

    return Scaffold(
      appBar: AppBar(title: Text(tr('result'))),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '$score / $total',
                style: Theme.of(context).textTheme.displayMedium,
              ),
              const SizedBox(height: 16),
              if (isExam) ...[
                if (timeUp) Text(tr('time_up'), style: const TextStyle(color: Colors.red)),
                Text(
                  passed ? tr('passed') : tr('failed'),
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                const SizedBox(height: 8),
                Text(rules.maxErrors != null
                    ? tr('max_err', {'e': errorsAllowed})
                    : tr('need_pass', {'p': need})),
              ],
              const SizedBox(height: 32),
              FilledButton(
                onPressed: () => Navigator.popUntil(context, (route) => route.isFirst),
                child: Text(tr('back_home')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
